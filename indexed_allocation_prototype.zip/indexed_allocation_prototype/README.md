# Disk Space Allocation Manager – Indexed Allocation

## About
This is a beginner-friendly browser prototype that simulates **indexed file allocation**. Each file has one index block. The index block stores the addresses of that file's data blocks.

## Features
- Enter a file name, index block number and comma-separated data block numbers.
- Checks that block numbers are valid (0–49).
- Checks that the index and data blocks are free before allocation.
- Prevents duplicate block numbers and duplicate file names.
- Displays free, index and data blocks in a 50-block disk map.
- Shows each file's index block and data block addresses.
- Release a file to make its blocks available again.
- Reset the disk to clear all allocations.

## Requirements
- Visual Studio Code
- Any modern web browser (Chrome, Edge or Firefox)

No Java, database, server or extension is required. This is a front-end simulation.

## Run in VS Code
1. Extract the ZIP file.
2. Open the extracted `indexed_allocation_prototype` folder in VS Code.
3. Open `index.html`.
4. Right-click inside the file and choose **Open with Live Server** if you have the Live Server extension.
5. If you do not have Live Server, open the folder in File Explorer and double-click `index.html`. It opens directly in your browser.

## How to test
1. Click **Load Example**.
2. Example values appear:
   - File name: `student.txt`
   - Index block: `5`
   - Data blocks: `2, 8, 12`
3. Click **Allocate File**.
4. The disk map marks block 5 as INDEX and blocks 2, 8 and 12 as DATA.
5. Try allocating another file using block 5. The system should reject it because block 5 is already occupied.
6. Click **Release file** to free the allocated blocks.
7. Click **Reset Disk** to clear all allocations.

## Indexed allocation – working
- The program first receives the file name, index block and required data block numbers.
- It validates the block numbers and checks whether all requested blocks are available.
- If every block is free, it allocates the index and data blocks.
- The index block stores the list of data block addresses.
- The allocation structure is displayed on the screen.

Example:
```text
File name       : student.txt
Index block     : 5
Data block list : 2, 8, 12

Index Block 5
    |-- Data Block 2
    |-- Data Block 8
    |-- Data Block 12
```

## Note
This is an educational prototype. Allocations are stored in browser memory while the page is open. Refreshing the page clears the allocations. It does not modify a real hard disk.
